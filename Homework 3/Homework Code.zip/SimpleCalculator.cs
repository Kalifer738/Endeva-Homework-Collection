﻿using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCalculator
{

    /// <summary>
    /// Unfinished calculator class which at the moment only partially supports works, didn't have the time to debug or to remember to implement PEMDAS.
    /// TOOD: PEMDAS
    /// TODO: Bignum
    /// TOOD: Use a tree to save operations (so it can be more easy to add operations)
    /// TODO: Do not hard lookup SQRT.
    /// </summary>
    internal class Calculator
    {

        /// <summary>
        /// A structure which holds a poitner to a function to run a funciton, as well as the string representing the operation.
        /// </summary>
        struct MathOperation
        {
            public string Word;
            public Func<double, double, double> FunctionOperation;

            public MathOperation(string Word, Func<double, double, double> FunctionOperation)
            {
                this.Word = Word;
                this.FunctionOperation = FunctionOperation;
            }
        }

        struct NumberAndOperation
        {
            public double Number;
            public MathOperation Operation;

            public NumberAndOperation(double Number, MathOperation Operation)
            {
                this.Number = Number;
                this.Operation = Operation;
            }
        }


        //static readonly string[] _definedOperations =
        //{
        //    "+",      //Sum
        //    "-",      //Subtraction
        //    "*",      //Multiplication
        //    "/",      //Division
        //    "sqrt",   //Squre root
        //    "^",      //Power 
        //    "%",      //Percent
        //    "(",      //Create a new sub expression
        //    ")",      //Evaluate previous and current sub expression
        //    ""        //No operation.
        //};

        //static readonly MathOperation[] _definedWordsAndOperations =
        //{
        //    new("+", _Addition),
        //    new("-", _Subtraction),
        //    new("*", _Multiplication),
        //    new("/", _Division),
        //    new("sqrt", _SquareRoot),
        //    new("^", _Power),
        //    new("%", _Percent),
        //    new("(", _OpenParenthesis),
        //    new(")", _CloseParenthesis),
        //};

        static readonly Dictionary<string, Func<double, double, double>> _wordToOperation = new Dictionary<string, Func<double, double, double>>
        {
          { "", _NoOperation },
          { "+", _Addition },
          { "-", _Subtraction },
          { "*", _Multiplication },
          { "/", _Division },
          { "sqrt", _SquareRoot },
          { "^", _Power },
          { "%", _Percent },
          { "(", _OpenParenthesis },
          { ")", _CloseParenthesis },
        };

        public Calculator()
        {

        }


        public string CalculateExpression(string expression)
        {
            StringBuilder sbExpression = new StringBuilder(expression);
            LinkedList<NumberAndOperation> subExpressions = new LinkedList<NumberAndOperation>();

            //Checks and inicialization of the loop...
            int currentExpressionDepth = 1;
            bool parsingExpression = true;
            int currentStringIndex = 0; //If it is a valid expression, it will be bigger than 0 when inside the main loop.
            {
                //Get the first operation/number
                var numberOrMathOperationAndNextIndexBeforeLoop = _GetNextNumberOrOperationAndOffset(sbExpression, currentStringIndex);
                bool validFirstExpression = false;
                currentStringIndex = numberOrMathOperationAndNextIndexBeforeLoop.Item3;

                //Make sure that expressions starting with + or - are valid (e.g. -(10), +(-10))
                if (numberOrMathOperationAndNextIndexBeforeLoop.Item2.Word == "-" || numberOrMathOperationAndNextIndexBeforeLoop.Item2.Word == "+")
                {
                    subExpressions.AddLast(new NumberAndOperation(0, numberOrMathOperationAndNextIndexBeforeLoop.Item2));
                    validFirstExpression = true;
                }
                //Make sure that expressions starting with a number are valid (e.g. 1, 3+3)
                else if (numberOrMathOperationAndNextIndexBeforeLoop.Item3 != -1)
                {
                    subExpressions.AddLast(new NumberAndOperation(numberOrMathOperationAndNextIndexBeforeLoop.Item1, new MathOperation("", _wordToOperation[""])));
                    validFirstExpression = true;
                }

                //Otherwise...
                if (!validFirstExpression)
                {
                    //This is not a valid string expresion!
                    return "This is not a valid expression.";
                }
            }
            //Loop checks and loop inicialization done

            while (parsingExpression)
            {
                if (currentStringIndex >= sbExpression.Length - 1)
                {
                    parsingExpression = false;
                    continue;
                }
                var numberOrMathOperationAndNextIndex = _GetNextNumberOrOperationAndOffset(sbExpression, currentStringIndex);

                //If this is an operation...
                if (numberOrMathOperationAndNextIndex.Item2.Word != "")
                {
                    //And the current operation is an (...
                    //Make sure that expressions such as "1+(1)" where +-*/(123 and +-*/(+- etc are still valid:
                    if (numberOrMathOperationAndNextIndex.Item2.Word == "(")
                    {
                        //And the operation beforehand is a +, -, *, /, ""...
                        if (subExpressions.Last.Value.Operation.Word == "+" ||
              subExpressions.Last.Value.Operation.Word == "-" ||
              subExpressions.Last.Value.Operation.Word == "*" ||
              subExpressions.Last.Value.Operation.Word == "/")
                        {
                            //Then add a new sub expression with a 0 number and the last operation, and Continue parsing the expression
                            subExpressions.AddLast(new NumberAndOperation(0, numberOrMathOperationAndNextIndex.Item2));
                            currentStringIndex = numberOrMathOperationAndNextIndex.Item3;
                            currentExpressionDepth++;
                            continue;
                        }
                        else if (subExpressions.Last.Value.Operation.Word == "")
                        {
                            //Then add a new sub expression with a 0 number and a multiply operation, and Continue parsing the expression
                            subExpressions.AddLast(new NumberAndOperation(0, new MathOperation("*", _wordToOperation["*"])));
                            currentStringIndex = numberOrMathOperationAndNextIndex.Item3;
                            currentExpressionDepth++;
                            continue;
                        }
                        else
                        {
                            //Then this is not a valid expression!
                            return "This is not a valid expression.";
                        }
                    }

                    //If the current operation is a )...
                    if (numberOrMathOperationAndNextIndex.Item2.Word == ")" && currentExpressionDepth > 1)
                    {
                        //Then we need to close the current sub expression and to create a new one
                        subExpressions.AddLast(new NumberAndOperation(0, new MathOperation(")", _wordToOperation[")"])));
                        currentStringIndex = numberOrMathOperationAndNextIndex.Item3;
                        currentExpressionDepth--;
                        continue;
                    }


                    //If there were no last operations ""
                    if (subExpressions.Last.Value.Operation.Word == "")
                    {
                        //Then we can just add the operation to the last sub expression
                        subExpressions.Last.Value = new NumberAndOperation(
              subExpressions.Last.Value.Number,
              numberOrMathOperationAndNextIndex.Item2
            );
                        currentStringIndex = numberOrMathOperationAndNextIndex.Item3;
                        continue;
                    }
                    //Otherwise if the last operation was a (
                    //else if ()

                    //Otherwise this is not a valid expression!
                    return "This is not a valid expression.";
                }

                //If this is a number...
                if (numberOrMathOperationAndNextIndex.Item3 > currentStringIndex)
                {
                    //And there were no last operation
                    if (subExpressions.Last.Value.Operation.Word == "")
                    {
                        //Then this is not a valid expression! "111 111"
                        return "This is not a valid expression.";
                    }

                    //If the last operation was a ) ( ...
                    if (subExpressions.Last.Value.Operation.Word == ")" ||
            subExpressions.Last.Value.Operation.Word == "(")
                    {
                        //Then set the current expression to this number
                        subExpressions.Last.ValueRef.Number = subExpressions.Last.ValueRef.Number + numberOrMathOperationAndNextIndex.Item1;
                        subExpressions.Last.ValueRef.Operation.Word = ""; //quickfix when opening brackets
                        currentStringIndex = numberOrMathOperationAndNextIndex.Item3;
                        continue;
                    }

                    //Otherwise apply the last operation to the last number and the current number
                    else
                    {
                        var num1 = subExpressions.Last.Value.Number;
                        var num2 = numberOrMathOperationAndNextIndex.Item1;
                        var operationFunc = subExpressions.Last.Value.Operation.FunctionOperation;
                        subExpressions.Last.ValueRef.Number = operationFunc.Invoke(num1, num2);
                        subExpressions.Last.ValueRef.Operation = new MathOperation("", _wordToOperation[""]);
                        currentStringIndex = numberOrMathOperationAndNextIndex.Item3;
                        continue;
                    }
                }

                //If there are no more numbers, mathmatical operations...
                if (numberOrMathOperationAndNextIndex.Item3 == -1)
                {
                    //And we've traversed the string builder...
                    if (currentStringIndex != sbExpression.Length - 1)
                    {
                        //This is an invalid expression
                        return "This is not a valid expression.";
                    }


                    ////there are no more sub expressions
                    //if (subExpressions.Count == 1)
                    //{
                    //    //We're done with the expression.
                    //    throw new NotImplementedException();
                    //    return subExpressions.First.Value.Number.ToString();
                    //}
                    //else
                    //{
                    //    //Otherwise now continue with the sub expressions
                    //    parsingExpression = false;
                    //    //throw new NotImplementedException(); 
                    //                                        //If I am correct, this should leave the
                    //                                         //expressions in a form where we just remove the paranthethies,
                    //                                         //and apply the leftover expressions withouth them
                    //                                         //Example:
                    //                                         //10+(1+3+(4+5+(1))) -> 10+(4+(9+(1))) then do smth here to get -> 10+4+9+1=>24
                    //}
                }
                //Otherwise continue breaking down the expression and point to the next possible number/expression...
                currentStringIndex = numberOrMathOperationAndNextIndex.Item3;
            }



            NumberAndOperation result = default;
            bool firstIteration = true;
            foreach (var expressionn in subExpressions)
            {
                if (expressionn.Number == 0 && expressionn.Operation.Word == ")")
                {
                    continue;
                }

                if (firstIteration)
                {
                    result = expressionn;
                    firstIteration = false;
                    Console.WriteLine(expressionn.Number);
                    Console.WriteLine(expressionn.Operation.Word);
                    Console.WriteLine();

                    continue;
                }
                result = new NumberAndOperation(
                  Number: result.Operation.FunctionOperation.Invoke(result.Number, expressionn.Number),
                  expressionn.Operation
                );


                Console.WriteLine(expressionn.Number);
                Console.WriteLine(expressionn.Operation.Word);
                Console.WriteLine();
            }

            Console.WriteLine(result.Number);



            throw new NotImplementedException();
            //Now solve the sub expressions which should be in the form of 10+(4+(9+(1)))
        }



        private static (double, MathOperation, int) _GetNextNumberOrOperationAndOffset(StringBuilder expression, int expressionOffset)
        {
            ////Check for numbers or operations until the end of the string.
            //for (int i = expressionOffset; i < expression.Length; i++)
            //{
            //    var currentChar = expression[i];

            //    //If we are inspecting a number...
            //    if (currentChar >= 51 && currentChar <= 60)
            //    {
            //        //Return a number
            //        var returnedNumberAndOffset = _GetNextNumber(expression, expressionOffset);
            //        return (returnedNumberAndOffset.Item1, new MathOperation("", _wordToOperation[""]), returnedNumberAndOffset.Item2);
            //    }
            //    else
            //    {
            //        //Else try to return an operation
            //        var returnedOperationAndOffset = _GetNextOperation(expression, expressionOffset);
            //        if(returnedOperationAndOffset.Item2 != -1)
            //        {
            //            return (0, returnedOperationAndOffset.Item1, returnedOperationAndOffset.Item2);
            //        }
            //    }

            //    //Otherwise we've encountered an invalid symbol.
            //}


            var currentChar = expression[expressionOffset];
            //If we are inspecting a number...
            if (currentChar >= 48 && currentChar <= 57)
            {
                //Return a number
                var returnedNumberAndOffset = _GetNextNumber(expression, expressionOffset);
                return (returnedNumberAndOffset.Item1, new MathOperation("", _wordToOperation[""]), returnedNumberAndOffset.Item2);
            }
            else
            {
                //Else try to return an operation
                var returnedOperationAndOffset = _GetNextOperation(expression, expressionOffset);
                if (returnedOperationAndOffset.Item2 != -1)
                {
                    return (0, returnedOperationAndOffset.Item1, returnedOperationAndOffset.Item2);
                }
            }

            //If we traversed the string, return a negative index to indicate that we couldn't find an operation or a number.
            return (0, new MathOperation("", _wordToOperation[""]), -1);
        }

        private static (double, int) _GetNextNumber(StringBuilder expression, int expressionOffset)
        {
            bool iteratedOnce = false;
            bool founddoublePoint = false;
            //Interate over all numbers and one "." symbol, until we hit the end of the string or something else.
            for (int i = expressionOffset + 1; i < expression.Length; i++)
            {
                var currentChar = expression[i];
                if (currentChar >= 48 && currentChar <= 57)
                {
                    continue;
                }
                else if (currentChar == '.' && !founddoublePoint)
                {
                    founddoublePoint = true;
                }
                else
                {
                    string textToConvert;
                    if (iteratedOnce)
                    {
                        textToConvert = expression.ToString(expressionOffset, i - expressionOffset);
                    }
                    else
                    {
                        textToConvert = expression.ToString(expressionOffset, 1);
                    }

                    //Offset "i" by one, as the current element has already been checked.
                    return (Convert.ToDouble(textToConvert), i++);
                }
            }

            return (0, -1);
        }

        private static (MathOperation, int) _GetNextOperation(StringBuilder expression, int expressionOffset)
        {
            Func<double, double, double> function;
            if (_wordToOperation.TryGetValue(expression[expressionOffset].ToString(), out function))
            {
                //Offset by one, as the current element has already been checked.
                return (new MathOperation(expression[expressionOffset].ToString(), function), expressionOffset + 1);
            }

            //Hardcoded to check if the operation could be SQRT, otherwise a tree can be used to search for words based on parts of the word "S" "Q" "R" "T" -> SQRT.
            if (expression.Length - expressionOffset == 3 && expression.ToString(expressionOffset, expressionOffset + 4) == "sqrt")
            {
                //Offset by 4, as the current element has already been checked.
                return (new MathOperation("sqrt", _wordToOperation["sqrt"]), expressionOffset + 4);
            }


            //Otherwise the current symbol/word is not a valid math operation

            expressionOffset = -1;
            return (new MathOperation("", _wordToOperation[""]), expressionOffset);

        }


        private static double _CloseParenthesis(double arg1, double arg2)
        {
            throw new NotImplementedException("Pending math updates so we can have expressions such as '3)'");
        }

        private static double _OpenParenthesis(double arg1, double arg2)
        {
            throw new NotImplementedException("Pending math updates so we can have expressions such as '3+('");
        }

        private static double _Percent(double arg1, double arg2)
        {
            return arg1 % arg2;
        }

        private static double _Power(double arg1, double arg2)
        {
            return Math.Pow(arg1, arg2);
        }

        private static double _SquareRoot(double arg1, double arg2)
        {
            return Math.Sqrt(arg1);
        }

        private static double _Division(double arg1, double arg2)
        {
            if (arg2 == 0) return 0; // Can't divide by zero
            return arg1 / arg2;
        }

        private static double _Multiplication(double arg1, double arg2)
        {
            return arg1 * arg2;
        }

        private static double _Subtraction(double arg1, double arg2)
        {
            return arg1 - arg2;
        }
        private static double _Addition(double arg1, double arg2)
        {
            return arg1 + arg2;
        }

        private static double _NoOperation(double arg1, double arg2)
        {
            throw new NotImplementedException();
        }
    }
}