﻿//https://introprogramming.info/intro-csharp-book/read-online/


using HomeworkUtilities;
using static HomeworkUtilities.Printer;
using SimpleCalculator;

namespace Hello_World
    {
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Printer Test Menu ===");
                Console.WriteLine("1. Test Laser Printer: which breaks only 10% of the time and can print 500 pages!");
                Console.WriteLine("2. Test Inkjet Printer: this one can only print 27 pagees and breaks 60% fo the time.");
                Console.WriteLine("3. Test Thermal Printer: This is the most realiable printer, printing 1000 pages and working 99% of the time!");
                Console.WriteLine("4. Exit");
                Console.Write("\nSelect an option: ");


                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        RunPrinterTest(PrinterType.LaserPrinter);
                        break;
                    case "2":
                        RunPrinterTest(PrinterType.InkjetPrinter);
                        break;
                    case "3":
                        RunPrinterTest(PrinterType.ThermalPrinter);
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("Invalid selection. Try again...");
                        Console.ReadKey();
                        break;
                }
            }
        }

        static void RunPrinterTest(PrinterType typeToTest)
        {
            Console.Clear();
            Console.WriteLine($"Starting test loop for {typeToTest}. Press CTRL+C to force quit, or wait for prompt.");

            while (true)
            {
                // Create a printer of the selected type
                Printer myPrinter = new Printer(typeToTest);

                Console.WriteLine($"\n--- New {typeToTest} Initialized ---");

                // Try to print 10 
                for (int i = 0; i < 10; i++)
                {
                    myPrinter.Print();
                    Console.WriteLine("\n");

                    if (myPrinter.Status != PrinterStatus.ReadyToPrint)
                    {
                        myPrinter.PrintPrinterStatus();
                        break; // Break inner for-loop on error
                    }
                }

                Console.WriteLine("Batch complete or stopped. Press 'Enter' to run again, or 'Esc' to return to menu.");
                var key = Console.ReadKey();

                if (key.Key == ConsoleKey.Escape)
                {
                    break; // Break the while(true) loop to return to menu
                }

                Console.Clear();
            }
        }
    }
}