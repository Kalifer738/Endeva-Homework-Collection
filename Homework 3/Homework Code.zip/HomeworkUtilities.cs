﻿namespace HomeworkUtilities
{
    /// <summary>
    /// A printer class used in our homework assignment.
    /// It covers Part 2 Coding exercise: 
    ///     6. namespace HomeworkUtilities with a class Printer that prints messages
    ///     7. Declaring varialbes of different types and using keywords.
    ///     8. Doing arithmetic (done on line 157 where it prints the remaining pages the printer can print)
    ///     MyBonus: It prints a pacman on a sheet of paper when you try to print, and with each print, there is a chance the printer breaks.
    /// </summary>
    class Printer
    {
        /// <summary>
        /// The number of pages a printer can print before it needs servicing.
        /// </summary>
        readonly int _maxPrintablePages;

        /// <summary>
        /// A random chance generator, used to determine if a printer gets defective after each print action. Do not share with consumers!
        /// </summary>
        Random _printerDefectGenerator;

        /// <summary>
        /// The chance in percentage (0.01f == 1%) that the printer will become defective.
        /// </summary>
        float _printerDefectChance;

        /// <summary>
        /// The type of the printer (e.g. Laser, Inkjet, Thermal).
        /// </summary>
        readonly PrinterType _printerType;

        /// <summary>
        /// Represents the current status of the printer (e.g. ReadyToPrint, OutOfPaper, Defected).
        /// </summary>
        PrinterStatus _printerStatus;



        /// <summary>
        /// Readonly.
        /// The number of pages a printer can print before it needs servicing.
        /// </summary>
        public int MaxPrintablePages
        {
            get { return _maxPrintablePages; }
        }

        /// <summary>
        /// Readonly.
        /// The type of the printer (e.g. Laser, Inkjet, Thermal).
        /// </summary>
        public PrinterType Type
        {
            get { return _printerType; }
        }

        /// <summary>
        /// Readonly.
        /// The current status of the printer (e.g. ReadyToPrint, OutOfPaper, Defected).
        /// </summary>
        public PrinterStatus Status { get; private set; }


        /// <summary>
        /// Readonly.
        /// The number of pages that have been printed after servicing.
        /// </summary>
        public int NumberOfPrintedPages { get; private set; }

        /// <summary>
        /// Readonly.
        /// Strings used to represent the printer types for customers. Order is based on the PrinterType enum.
        /// </summary>
        readonly string[] _printerTypeTextRepresentationForCustomers =
        {
            "Laser Printer",
            "Inkjet Printer",
            "Thermal Printer"
        };

        /// <summary>
        /// Readonly.
        /// Strings used to represent the printer errros for customers. Order is based on the PrinterStatus enum.
        /// </summary>
        readonly string[] _printerStatusTextRepresentationForCustomers =
        {
            "Ready to Print",
            "Out of Paper",
            "Defect"
        };



        public enum PrinterType
        {
            LaserPrinter,
            InkjetPrinter,
            ThermalPrinter
        }

        public enum PrinterStatus
        {
            ReadyToPrint,
            OutOfPaper,
            Defected
        }


        /// <summary>
        /// Create a printer with a specific type.
        /// </summary>
        /// <param name="printerType">The type of printer.</param>
        /// <exception cref="NotImplementedException">Exception thrown when the printerType is not implemented.</exception>
        public Printer(PrinterType printerType)
        {
            // Wanted to use compile time assertion (so it fails even before it compiles to full code) like in C++, but C# does not support it yet...
            //  And this doesn't seem like good practice, as if it doesn't fail at compile time, might as well know the requirements or have a unit test for it.
            //Debug.Assert(Enum.GetNames(typeof(PrinterType)).Length == printerTypeTextRepresentationForCustomers.Length, "The number of printer types does not match the number of text representations.");

            _printerType = printerType;
            NumberOfPrintedPages = 0;
            _printerDefectGenerator = new Random();

            /// Define maxPrintablePages and printerDefectChance based on printer type, or throw exception if it is not defined.
            switch (printerType)
            {
                case PrinterType.LaserPrinter: _maxPrintablePages = 500; _printerDefectChance = 10f; break;
                case PrinterType.InkjetPrinter: _maxPrintablePages = 27; _printerDefectChance = 60f; break;
                case PrinterType.ThermalPrinter: _maxPrintablePages = 1000; _printerDefectChance = 1f; break;
                default: throw new NotImplementedException($"printerMaxPages is not defined in the constructor for printer '{_GetPrinterTypeTextForCustomers(printerType)}'. Please define it");
            }
        }



        /// <summary>
        /// Prints the current status of the printer for customers.
        /// </summary>
        public void PrintPrinterStatus()
        {
            //Check if the printer can print, otherwise print an error....
            if (!_CanPrintShowError())
            {
                //and exit the function.
                return;
            }

            if(_TryDefectPrinter())
            {
                //If the printer got defective, set its status to Defected and inform the customer.
                Status = PrinterStatus.Defected;
                Console.WriteLine($"There was an issue with printing. Please check status!");
                return;
            }

            //Otherwise say that the printer is ready to print as there are no other errors.
            Console.WriteLine($"Printer is ready to print!{Environment.NewLine}This {_GetPrinterTypeTextForCustomers(Type)} has printed {NumberOfPrintedPages} pages out of {MaxPrintablePages}.{Environment.NewLine}Printer can print {MaxPrintablePages - NumberOfPrintedPages} more pages.");
        }

        /// <summary>
        /// Prints a page of what you wanted to print, and of course if the printer is also able to print.
        /// </summary>
        public void Print()
        {
            //Check if the printer can print, otherwise print an error....
            if (!_CanPrintShowError())
            {
                //and exit the function.
                return;
            }

            Console.WriteLine("Buzzz, printer is busy.");
            NumberOfPrintedPages++;

            // Simulate printing time
            Thread.Sleep(500);

            //If the printer got defective during printing...
            if (_TryDefectPrinter())
            {
                //Then set its status to Defected and inform the customer to check the status.
                Status = PrinterStatus.Defected;
                Console.WriteLine($"There was an issue with printing. Please check status!");
                return;
            }

            Console.WriteLine("Printer has finished printing! Here is the sheet of paper");
            Console.WriteLine("|------------------------------------|\r\n|   ,##.                   ,==.      |\r\n| ,#    #.                 \\ o ',    |\r\n|#        #     _     _     \\    \\   |\r\n|#        #    (_)   (_)    /    ;   |\r\n| `#    #'                 /   .'    |\r\n|   `##'                   \"==\"      |\r\n|------------------------------------|");
        }

        /// <summary>
        /// Returns a string representation of the printer type for customer view.
        /// </summary>
        /// <param name="printerType"></param>
        /// <returns></returns>
        private string _GetPrinterTypeTextForCustomers(PrinterType printerType)
        {
            return _printerTypeTextRepresentationForCustomers[(int)printerType];
        }

        /// <summary>
        /// Returns a string representation of the printer status for customer view.
        /// </summary>
        /// <param name="printerStatus"></param>
        /// <returns></returns>
        private string _GetPrinterStatusTextForCustomers(PrinterStatus printerStatus)
        {
            return _printerStatusTextRepresentationForCustomers[(int)printerStatus];
        }

        private bool _CanPrint()
        {
            return Status == PrinterStatus.ReadyToPrint && NumberOfPrintedPages < MaxPrintablePages;
        }

        /// <summary>
        /// Returns true if the printer can print, otherwise prints an error message and returns false.
        /// </summary>
        /// <returns>Boolean representing if the printer can print</returns>
        private bool _CanPrintShowError()
        {
            if (Status != PrinterStatus.ReadyToPrint)
            {
                Console.WriteLine($"Printer cannot print because its status is {_GetPrinterStatusTextForCustomers(Status)} and needs a certified expert to service it!");
                Console.WriteLine("To contact an expert, please call +359 XXX XXXX");
                return false;
            }
            if (NumberOfPrintedPages >= MaxPrintablePages)
            {
                Console.WriteLine("Printer has reached its maximum printable pages and needs a certified expert to service it!");
                Console.WriteLine("To contact an expert, please call +359 XXX XXXX");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Tries to defect the printer based on the defect chance. Returns true if the printer got defective, otherwise false.
        /// </summary>
        /// <returns>A boolean indicating if the printer got defective.</returns>
        private bool _TryDefectPrinter()
        {
            float randomValue = _printerDefectGenerator.Next(0, 100);
            return randomValue < _printerDefectChance;
        }
    }
}